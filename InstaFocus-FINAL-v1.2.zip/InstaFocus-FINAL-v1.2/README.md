# InstaFocus 1.2

This build removes Kotlin source files entirely. The app is Java-only so GitHub Actions builds `:app:assembleDebug` without a `compileDebugKotlin` task.

The overlay implementation also keeps windows alive between accessibility events instead of removing/recreating them on every event, preventing the blinking behavior from the earlier build.

Build with JDK 17 and Gradle 8.7. The workflow is `.github/workflows/android.yml`.
