package com.instafocus;

import android.accessibilityservice.AccessibilityService;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;

public class InstaAccessibilityService extends AccessibilityService {
    private static final String INSTAGRAM = "com.instagram.android";
    private static final Object REFRESH_TOKEN = new Object();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<BlockView> views = new ArrayList<>();
    private android.content.SharedPreferences prefs;
    private boolean instagramForeground = false;
    private Mode mode = Mode.NONE;
    private boolean searchHasQuery = false;
    private boolean allowSharedViewer = false;
    private OverlaySpec lastApplied = OverlaySpec.none();

    private enum Mode { NONE, HOME, REELS, SEARCH, MESSAGES, OTHER }
    private static final class OverlaySpec {
        final Kind kind; final boolean quote; final int width; final int height;
        enum Kind { NONE, HOME, REELS, SEARCH }
        OverlaySpec(Kind k, boolean q, int w, int h) { kind=k; quote=q; width=w; height=h; }
        static OverlaySpec none() { return new OverlaySpec(Kind.NONE,false,0,0); }
        @Override public boolean equals(Object o) { if (!(o instanceof OverlaySpec)) return false; OverlaySpec x=(OverlaySpec)o; return kind==x.kind && quote==x.quote && width==x.width && height==x.height; }
        @Override public int hashCode() { return (((kind.hashCode()*31)+(quote?1:0))*31+width)*31+height; }
    }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        setServiceInfoWithFlags();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        instagramForeground = root != null && INSTAGRAM.equals(String.valueOf(root.getPackageName()));
        scheduleRefresh(0);
    }

    private void setServiceInfoWithFlags() {
        android.accessibilityservice.AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            setServiceInfo(info);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        String pkg = event.getPackageName() == null ? "" : event.getPackageName().toString();
        if (getPackageName().equals(pkg)) return;
        if (!INSTAGRAM.equals(pkg)) {
            if (instagramForeground) {
                instagramForeground=false; mode=Mode.NONE; searchHasQuery=false; allowSharedViewer=false; applyOverlay(OverlaySpec.none());
            }
            return;
        }
        instagramForeground=true;
        scheduleRefresh(140);
    }

    @Override public void onInterrupt() {}

    private void scheduleRefresh(long delay) {
        handler.removeCallbacksAndMessages(REFRESH_TOKEN);
        handler.postAtTime(this::refresh, REFRESH_TOKEN, SystemClock.uptimeMillis()+delay);
    }

    private void refresh() {
        if (!instagramForeground) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        State state = detectMode(root);
        if (state.mode != Mode.NONE) {
            if (mode == Mode.MESSAGES && state.mode == Mode.REELS) allowSharedViewer=true;
            else if (state.mode == Mode.MESSAGES || state.mode == Mode.HOME || state.mode == Mode.SEARCH) allowSharedViewer=false;
            mode=state.mode;
        }
        searchHasQuery=state.query;
        applyOverlay(desiredOverlaySpec());
    }

    private OverlaySpec desiredOverlaySpec() {
        int w=getResources().getDisplayMetrics().widthPixels, h=getResources().getDisplayMetrics().heightPixels;
        if (prefs == null) prefs=getSharedPreferences("settings",MODE_PRIVATE);
        switch(mode) {
            case HOME: return prefs.getBoolean("home",true) ? new OverlaySpec(OverlaySpec.Kind.HOME,false,w,h) : OverlaySpec.none();
            case REELS: return prefs.getBoolean("reels",true) && !allowSharedViewer ? new OverlaySpec(OverlaySpec.Kind.REELS,false,w,h) : OverlaySpec.none();
            case SEARCH: return prefs.getBoolean("search",true) && !searchHasQuery ? new OverlaySpec(OverlaySpec.Kind.SEARCH,prefs.getBoolean("quote",true),w,h) : OverlaySpec.none();
            default: return OverlaySpec.none();
        }
    }

    private static final class State { final Mode mode; final boolean query; State(Mode m,boolean q){mode=m;query=q;} }
    private State detectMode(AccessibilityNodeInfo root) {
        if (root==null) return new State(Mode.NONE,false);
        List<AccessibilityNodeInfo> nodes=new ArrayList<>(); collect(root,nodes,0);
        boolean reels=false,search=false,home=false,messages=false,query=false;
        for (AccessibilityNodeInfo n:nodes) {
            String raw=n.getText()==null?"":n.getText().toString().trim();
            String cd=n.getContentDescription()==null?"":n.getContentDescription().toString().trim();
            String t=(raw+" "+cd).toLowerCase();
            if ("reels".equals(t) || (t.contains("reels") && n.isSelected())) reels=true;
            if ("search".equals(t) || t.contains("search and explore") || t.contains("search tab")) search=true;
            if ("home".equals(t) || t.contains("home tab")) home=true;
            if (t.contains("messages") || t.contains("direct")) messages=true;
            if (n.isEditable() && !raw.isEmpty()) query=true;
        }
        Mode result;
        if (reels && likelyReels(nodes)) result=Mode.REELS;
        else if (search && likelySearch(nodes)) result=Mode.SEARCH;
        else if (messages && likelyMessages(nodes)) result=Mode.MESSAGES;
        else if (home) result=Mode.HOME;
        else result=Mode.NONE;
        return new State(result,query);
    }

    private boolean likelyReels(List<AccessibilityNodeInfo> nodes){int c=0;for(AccessibilityNodeInfo n:nodes){String t=((n.getText()==null?"":n.getText().toString())+" "+(n.getContentDescription()==null?"":n.getContentDescription().toString())).toLowerCase();if(t.contains("reels")||t.contains("likes")||t.contains("comments")||t.contains("audio"))c++;}return c>=2;}
    private boolean likelySearch(List<AccessibilityNodeInfo> nodes){for(AccessibilityNodeInfo n:nodes){String t=((n.getText()==null?"":n.getText().toString())+" "+(n.getContentDescription()==null?"":n.getContentDescription().toString())).toLowerCase();if(t.contains("search")&&(n.isFocused()||n.isEditable()))return true;}for(AccessibilityNodeInfo n:nodes){if(n.getText()!=null&&n.getText().toString().toLowerCase().contains("for you"))return true;}return false;}
    private boolean likelyMessages(List<AccessibilityNodeInfo> nodes){int c=0;for(AccessibilityNodeInfo n:nodes){String t=((n.getText()==null?"":n.getText().toString())+" "+(n.getContentDescription()==null?"":n.getContentDescription().toString())).toLowerCase();if(t.contains("message")||t.contains("chat"))c++;}return c>=2;}
    private void collect(AccessibilityNodeInfo node,List<AccessibilityNodeInfo> out,int depth){if(depth>18||out.size()>400)return;out.add(node);for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo c=node.getChild(i);if(c!=null)collect(c,out,depth+1);}}

    private void applyOverlay(OverlaySpec spec) {
        if (spec.equals(lastApplied)) return;
        clearOverlays(); lastApplied=spec;
        if(spec.kind==OverlaySpec.Kind.NONE)return;
        switch(spec.kind){
            case HOME: addBlock(0,(int)(spec.height*.245f),spec.width,(int)(spec.height*.91f),"home-feed",false); addBlock((int)(spec.width*.20f),(int)(spec.height*.91f),(int)(spec.width*.40f),spec.height,"reels-nav",false); break;
            case REELS: addBlock(0,0,spec.width,spec.height,"reels-full",false); break;
            case SEARCH: addBlock(0,(int)(spec.height*.20f),spec.width,(int)(spec.height*.46f),"search-suggestions",spec.quote); break;
            default: break;
        }
    }

    private void addBlock(int left,int top,int right,int bottom,String id,boolean quote){
        if(right<=left||bottom<=top)return;
        WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        BlockView view=new BlockView(this,quote);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(right-left,bottom-top,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.START; p.x=left; p.y=top; p.setTitle("InstaFocus:"+id);
        try{wm.addView(view,p);views.add(view);}catch(Exception ignored){}
    }
    private void clearOverlays(){WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);for(BlockView v:new ArrayList<>(views)){try{wm.removeViewImmediate(v);}catch(Exception ignored){}}views.clear();}
    @Override public void onDestroy(){handler.removeCallbacksAndMessages(REFRESH_TOKEN);clearOverlays();super.onDestroy();}

    private class BlockView extends View {
        private final boolean drawQuote; private float downX,downY; private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        BlockView(android.content.Context c,boolean q){super(c);drawQuote=q;setClickable(true);setOnTouchListener((v,e)->{handleTouch(e);return true;});}
        private void handleTouch(MotionEvent e){if(mode==Mode.REELS&&!allowSharedViewer){if(e.getActionMasked()==MotionEvent.ACTION_DOWN){downX=e.getRawX();downY=e.getRawY();}else if(e.getActionMasked()==MotionEvent.ACTION_UP){float dx=e.getRawX()-downX,dy=Math.abs(e.getRawY()-downY);if(downX<70f&&dx>110f&&dy<140f)performGlobalAction(GLOBAL_ACTION_BACK);}}}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);if(!drawQuote)return;boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Paint.create("sans",Paint.NORMAL));paint.setColor(dark?Color.WHITE:Color.rgb(25,25,28));float cx=getWidth()/2f;paint.setTextSize(Math.max(25f,Math.min(40f,getWidth()*.052f)));canvas.drawText("Protect your attention.",cx,getHeight()*.43f,paint);paint.setTextSize(Math.max(18f,Math.min(27f,getWidth()*.036f)));canvas.drawText("Search with purpose, then leave.",cx,getHeight()*.58f,paint);paint.setColor(Color.rgb(131,58,180));paint.setTextSize(Math.max(17f,Math.min(25f,getWidth()*.033f)));canvas.drawText("InstaFocus",cx,getHeight()*.75f,paint);}
    }
}
