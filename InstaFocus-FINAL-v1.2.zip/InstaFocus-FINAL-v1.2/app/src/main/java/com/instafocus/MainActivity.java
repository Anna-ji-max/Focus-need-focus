package com.instafocus;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.view.accessibility.AccessibilityManager;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private android.content.SharedPreferences prefs;
    private TextView statusText;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        if (statusText != null) updateStatus();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(24));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("InstaFocus"); title.setTextSize(34); title.setTextColor(Color.WHITE);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title, lp());

        TextView subtitle = new TextView(this);
        subtitle.setText("Keep Instagram social, remove the infinite scroll."); subtitle.setTextSize(17); subtitle.setTextColor(Color.LTGRAY);
        root.addView(subtitle, lp(0, 8));

        statusText = new TextView(this); statusText.setTextSize(15); statusText.setPadding(dp(14), dp(12), dp(14), dp(12));
        statusText.setBackgroundColor(Color.rgb(35,35,42)); root.addView(statusText, lp(0,20));

        addSwitch(root, "Block Home feed", "home", true);
        addSwitch(root, "Block Reels", "reels", true);
        addSwitch(root, "Hide Search suggestions", "search", true);
        addSwitch(root, "Show motivational quote in Search", "quote", true);

        Button accessibility = new Button(this);
        accessibility.setText("1. Enable Accessibility Service");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility, lp(0,22));

        TextView note = new TextView(this);
        note.setText("The service only activates when Instagram is the foreground app. Stories and direct messages stay usable; blocked areas consume touches so they cannot be scrolled.");
        note.setTextSize(14); note.setTextColor(Color.GRAY); note.setPadding(0, dp(16), 0, 0);
        root.addView(note, lp());
        getWindow().getDecorView().setBackgroundColor(Color.rgb(14,14,18));
        updateStatus();
    }

    private void addSwitch(LinearLayout parent, String label, String key, boolean def) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(10),0,dp(10));
        TextView text = new TextView(this); text.setText(label); text.setTextSize(17); text.setTextColor(Color.WHITE);
        Switch toggle = new Switch(this); toggle.setChecked(prefs.getBoolean(key, def));
        toggle.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean(key, checked).apply());
        row.addView(text, new LinearLayout.LayoutParams(0,-2,1f)); row.addView(toggle); parent.addView(row, lp());
    }

    private void updateStatus() {
        boolean on = isAccessibilityServiceEnabled();
        statusText.setText("Accessibility: " + (on ? "ON" : "OFF"));
        statusText.setTextColor(on ? Color.GREEN : Color.RED);
    }

    private boolean isAccessibilityServiceEnabled() {
        AccessibilityManager manager = (AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
        for (AccessibilityServiceInfo info : manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
            android.accessibilityservice.AccessibilityServiceInfo.ServiceInfo s = null;
            if (info.resolveInfo != null) s = info.resolveInfo.serviceInfo;
            if (s != null && new ComponentName(s.packageName, s.name).equals(new ComponentName(this, InstaAccessibilityService.class))) return true;
        }
        return false;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams lp() { return lp(0,0); }
    private LinearLayout.LayoutParams lp(int top, int bottom) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(top),0,dp(bottom)); return p; }
}
